
@extends($activeTemplate .'layouts.master')
@php
    $banners = getContent('banner.element');
@endphp

@section('content')

<section class="wsus__faq pt_115 xs_pt_75 pb_120 xs_pb_80">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-12">
                <div class="wsus__faq_text">
                    <h3>Frequently asked questions</h3>
                    <div class="accordion accordion-flush" id="accordionFlushExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-heading1">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#flush-collapse1" aria-expanded="false"
                                    aria-controls="flush-collapse1">
                                    1. How do I sell my smartphone?
                                </button>
                            </h2>
                            <div id="flush-collapse1" class="accordion-collapse collapse"
                                aria-labelledby="flush-heading1" data-bs-parent="#accordionFlushExample" style="">
                                <div class="accordion-body">
                                    <p>To sell your smartphone, simply select the model and condition of your device and
                                        we will provide you with an instant quote.</p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-heading2">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#flush-collapse2" aria-expanded="false"
                                    aria-controls="flush-collapse2">
                                    2. What types of devices can I sell?
                                </button>
                            </h2>
                            <div id="flush-collapse2" class="accordion-collapse collapse "
                                aria-labelledby="flush-heading2" data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <p>You can sell smartphones, tablets, and game consoles of various brands and models.</p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-heading3">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#flush-collapse3" aria-expanded="false"
                                    aria-controls="flush-collapse3">
                                    3. How do I get paid for my device?
                                </button>
                            </h2>
                            <div id="flush-collapse3" class="accordion-collapse collapse "
                                aria-labelledby="flush-heading3" data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <p>TOnce we receive and inspect your device, we will send your payment via your chosen method.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection


